/**
 * AWS Lambda Function Handler for HTTP requests via Lambda Function URLs
 * 
 * This handler processes HTTP requests and returns a message including the ENV environment variable for GET requests to "/"
 */

exports.handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    
    // Extract request details
    const path = event.rawPath || event.requestContext?.http?.path || '/';
    const method = event.requestContext?.http?.method || 'GET';
    
    // Handle the root path
    if (path === '/' && method === 'GET') {
        // Get the ENV environment variable value
        const envValue = process.env.ENV || '';
        
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
            },
            body: `Hello from the ${envValue} environment`,
        };
    }
    
    // Handle other paths
    return {
        statusCode: 404,
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            message: 'Not Found',
            path: path,
            method: method,
        }),
    };
};
